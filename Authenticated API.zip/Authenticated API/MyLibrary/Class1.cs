﻿namespace MyLibrary;

public class Class1
{

}
